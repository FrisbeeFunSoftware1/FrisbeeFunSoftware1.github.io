package DataBase.utility;

public enum Unit {
    Metric, USCS;
}
