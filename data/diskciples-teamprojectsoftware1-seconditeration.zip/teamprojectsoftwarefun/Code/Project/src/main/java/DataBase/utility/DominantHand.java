package DataBase.utility;

public enum  DominantHand {
    Right, Left, Ambidextrious;
}
