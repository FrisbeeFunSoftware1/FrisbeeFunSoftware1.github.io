package graphicalUserInterface.game;

import actionPackage.Catch;
import actionPackage.Injury;
import actionPackage.PassTo;
import database.DBConnection;
import database.GameHandler;
import graphicalUserInterface.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Logger;

public class GameController {
	public static final Logger logger = Logger.getLogger(GameController.class.getName());

	private GameHandler gh = new GameHandler();

	@SuppressWarnings("unused")
	private ObservableList<String> playerList;

	@SuppressWarnings("rawtypes")
	@FXML
	private ChoiceBox Players;

	@SuppressWarnings("rawtypes")
	@FXML
	private ChoiceBox Players1;

	@FXML
	private TextField textBox;

	private String prev;

	private String previousPrev;

	@SuppressWarnings("unchecked")
	@FXML
	public void initialize() throws SQLException {
		ArrayList<String> tempArray = new ArrayList<>();
		Connection dbConnection = DBConnection.getInstance().getConnection();
		try (Statement statement = dbConnection.createStatement()) {
			try (ResultSet rs = statement.executeQuery("Select name from theprojectdata.currentplayers")) {
				if (rs.next()) {
					do {
						tempArray.add(rs.getString("name"));
					} while (rs.next());
				}
				ObservableList<String> playerList = FXCollections.observableArrayList(tempArray);
				Players.setItems(playerList);
				Players1.setItems(playerList);
				textBox.setText(playerList.get(0));
				prev = textBox.getText();
				previousPrev = prev;
			    rs.close();
			}
			statement.close();
		}
	}

	@FXML
	private void goCancel() throws IOException {
		Main.showMainItems();
	}

	@FXML
	private void goGameOver() throws IOException, SQLException {
		gh.recordAll();
		Connection dbConnection = DBConnection.getInstance().getConnection();

		try (Statement statement = dbConnection.createStatement()) {
			statement.execute("Update theprojectdata.player set gamesplayed = gamesplayed + 1");
		    statement.close();
		}

		Main.showGameOverScene();
		dbConnection = null;
	}

	@FXML
	private void goPenalty() {
		gh.undo();
		textBox.setText(previousPrev);
		prev = previousPrev;
	}

	@FXML
	private void goInjury() throws SQLException {
		if (Players1 != null) {
			Connection dbConnection = DBConnection.getInstance().getConnection();
			try (Statement statement = dbConnection.createStatement()) {
				Injury i;
				String query = String.format("Select idPlayer from theprojectdata.player where name = \'%s\';",
						Players1.getValue());
				try (ResultSet rs = statement.executeQuery(query)) {
					if (rs.next()) {
						i = new Injury(rs.getLong("idPlayer"), Players1.getValue() + " was injured");
						gh.newAction(i);
					}
					rs.close();
				}
				statement.close();
			}
			dbConnection = null;
		}
	}

	@FXML
	private void goTurnover() throws IOException, SQLException {
		Connection dbConnection = DBConnection.getInstance().getConnection();
		try (Statement statement = dbConnection.createStatement()) {
			PassTo pt;
			String query = String.format("Select idPlayer from theprojectdata.currentplayers where name = \'%s\';",
					prev);
			try (ResultSet rs = statement.executeQuery(query)) {
				if (rs.next()) {
					do {
						pt = new PassTo(rs.getLong("idPlayer"), prev + " failed to pass");
						gh.newAction(pt);
					} while (rs.next());
				}
				Main.showTurnoverScene();
				rs.close();
			}
			statement.close();
		}
		dbConnection = null;

	}

	@FXML
	private void goCompletion() throws SQLException {
		String temp = Players.getValue().toString();
		Connection dbConnection = DBConnection.getInstance().getConnection();
		PassTo pt;
		Long id = null;
		Catch c;
		try (Statement statement = dbConnection.createStatement()) {
			String query = String.format("Select idPlayer from theprojectdata.currentplayers where name = \'%s\';", prev);
			try (ResultSet r1 = statement.executeQuery(query)) {
				if (r1.next()) {
					id = r1.getLong("idPlayer");
				}
				query = String.format("Select idPlayer from theprojectdata.currentplayers where name = \'%s\';", temp);
				try (ResultSet rs = statement.executeQuery(query)) {
					if (rs.next()) {
						do {
							pt = new PassTo(id, rs.getLong("idPlayer"), prev + " passed to " + temp);
							c = new Catch(rs.getLong("idPlayer"), temp + " caught a pass");
							gh.newAction(pt);
							gh.newAction(c);
						} while (rs.next());
					}
					textBox.setText(Players.getValue().toString());
					rs.close();
				}
			    r1.close();
			}
			statement.close();
		}
		previousPrev = prev;
		prev = temp;
		textBox.setText(Players.getValue().toString());
		dbConnection = null;
	}

	@FXML
	private void goScore() throws SQLException, IOException {
		gh.recordAll();
		Main.showPreGameScene();
	}

	public String getPrev() {
		return prev;
	}

	public void setPrev(String prev) {
		this.prev = prev;
	}

	public String getPreviousPrev() {
		return previousPrev;
	}

	public void setPreviousPrev(String previousPrev) {
		this.previousPrev = previousPrev;
	}
}
