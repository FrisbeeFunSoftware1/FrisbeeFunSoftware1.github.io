package graphicalUserInterface.view;

import javafx.fxml.FXML;

import java.io.IOException;

import static graphicalUserInterface.Main.showMainItems;

public class MainViewController {

    @FXML
    private void goHome() throws IOException {
        showMainItems();
    }

}
