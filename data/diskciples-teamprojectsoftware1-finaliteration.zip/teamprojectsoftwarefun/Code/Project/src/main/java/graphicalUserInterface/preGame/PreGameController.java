package graphicalUserInterface.preGame;

import graphicalUserInterface.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import database.DBConnection;

import static graphicalUserInterface.Main.showGameScene;
import static graphicalUserInterface.Main.showMainItems;

public class PreGameController {

    public static final Logger logger = Logger.getLogger(PreGameController.class.getName());

    @FXML
    private ChoiceBox<String> Player1;
    @FXML
    private ChoiceBox<String> Player2;
    @FXML
    private ChoiceBox<String> Player3;
    @FXML
    private ChoiceBox<String> Player4;
    @FXML
    private ChoiceBox<String> Player5;
    @FXML
    private ChoiceBox<String> Player6;
    @FXML
    private ChoiceBox<String> Player7;

    @FXML
    private void goCancel() throws IOException {
        showMainItems();
    }

    @FXML
    private void goGame() throws IOException, SQLException {
        ArrayList<String> tempArray = new ArrayList<>();
        tempArray.add(Player1.getValue());
        tempArray.add(Player2.getValue());
        tempArray.add(Player3.getValue());
        tempArray.add(Player4.getValue());
        tempArray.add(Player5.getValue());
        tempArray.add(Player6.getValue());
        tempArray.add(Player7.getValue());

        Connection dbConnection = DBConnection.getInstance().getConnection();
        if (dbConnection == null) {
            throw new SQLException("getDBConnection returned a null connection.");
        }

        try (Statement statement = dbConnection.createStatement()) {
            statement.execute("Delete from theprojectdata.currentplayers");
            for (int i = 0; i < tempArray.size(); i++) {
                String query = String.format("Insert into TheProjectData.CurrentPlayers values(\'%d\', \'%s\');", i + 1, tempArray.get(i));
                statement.execute(query);
            }
            statement.close();
        }
        showGameScene();
    }

    @FXML
    private void goTurnover() throws IOException {
        Main.showTurnoverScene();
    }

    @FXML
    private void initialize() throws SQLException {
        Connection dbConnection = DBConnection.getInstance().getConnection();
        if (dbConnection == null) {
            throw new SQLException("getDBConnection returned a null connection.");
        }
        try (Statement statement = dbConnection.createStatement()) {
            String query = "Select name from TheProjectData.Player";
            ArrayList<String> tempArray = new ArrayList<>();
            try (ResultSet rs = statement.executeQuery(query)) {
                if (rs.next()) {
                    do {
                        logger.log(Level.WARNING, rs.getString("name"));
                        tempArray.add(rs.getString("name"));
                    } while (rs.next());
                }

                ObservableList<String> available = FXCollections.observableArrayList(tempArray);
                Player1.setItems(available);
                Player2.setItems(available);
                Player3.setItems(available);
                Player4.setItems(available);
                Player5.setItems(available);
                Player6.setItems(available);
                Player7.setItems(available);

                rs.close();
            }
            statement.close();
        }
    }
}
