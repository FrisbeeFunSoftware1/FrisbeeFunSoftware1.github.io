package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {
	public static final Logger logger = Logger.getLogger(DBConnection.class.getName());
	private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_CONNECTION = "jdbc:mysql://localhost/TheProjectData";
	private static String username = "";
	private static String password = "";
	
	private static DBConnection single_instance = null;
	
	private DBConnection() {
		DBConnection.setPassword(null);
		DBConnection.setUsername(null);
	}
	
	public static DBConnection getInstance() 
    { 
        if (single_instance == null) 
            single_instance = new DBConnection(); 
  
        return single_instance; 
    }
	
	public void setCredentials(String u, String p) {
		DBConnection.setUsername(u);
		DBConnection.setPassword(p);
	}
	
	private static void setPassword(String p) {
		DBConnection.password = p;
		
	}

	private static void setUsername(String u) {
		DBConnection.username = u;
		
	}

	public Connection getConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			logger.log(Level.WARNING, e.getMessage());
			logger.log(Level.SEVERE, "Failed to establish database");
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, username, password);
			return dbConnection;
		} catch (SQLException e) {
			logger.log(Level.WARNING, e.getMessage());
		}
		return dbConnection;
	}
}
