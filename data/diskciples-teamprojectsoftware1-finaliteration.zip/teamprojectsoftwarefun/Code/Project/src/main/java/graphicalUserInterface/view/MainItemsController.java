package graphicalUserInterface.view;

import java.io.IOException;

import graphicalUserInterface.Main;
import javafx.fxml.FXML;

public class MainItemsController {

	@FXML
	private void goCreatePlayer() throws IOException {
		Main.showCreatePlayerScene();

	}

	@FXML
	private void goPreGame() throws IOException {
		Main.showPreGameScene();
	}

	@FXML
	private void goPlayerStats() throws IOException {
		Main.showPlayerStatsScene();
	}

	@FXML
	private void exitProgram() {
		System.exit(0);
	}
}
