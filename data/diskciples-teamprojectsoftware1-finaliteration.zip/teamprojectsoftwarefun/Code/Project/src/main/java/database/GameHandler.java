package database;

import actionPackage.Action;
import actionPackage.ActionEnum;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.logging.Logger;

// toString uses StringBuilder, which uses the Builder Design Pattern.
public class GameHandler extends GameHandlerFactory {
	public static final Logger logger = Logger.getLogger(GameHandler.class.getName());

	private Map<Long, Player> playerList;
	private Deque<Action> stack = new ArrayDeque<>();

	public GameHandler() {
		this(new HashMap<>());
	}

	protected GameHandler(Map<Long, Player> roster) {
		playerList = Objects.requireNonNull(roster);
	}

	public void newAction(Action a) {
		stack.add(a);
	}

	/**
	 * Removes last action completed from the stack.
	 */
	public void undo() {
		stack.removeLast();
	}

	/**
	 * Calculates stats from the actions done throughout the game. Records in
	 * database.
	 */
	public void recordAll() throws SQLException {
		Connection dbConnection;

		while (!stack.isEmpty()) {
			dbConnection = DBConnection.getInstance().getConnection();
			if (dbConnection == null) {
				throw new SQLException("getDBConnection returned a null connection.");
			}

			String query = "";
			try (Statement statement = dbConnection.createStatement()) {
				if (stack.getFirst().getActionName().equals(ActionEnum.PASSCOMPLETE)) {
					query = String.format(
							"update theprojectdata.player set passes = passes + 1, completions = completions + 1 where idPlayer = \'%d\';",
							stack.getFirst().getId());
				} else if (stack.getFirst().getActionName().equals(ActionEnum.PASSFAIL)) {
					query = String.format(
							"update theprojectdata.player set passes = passes + 1 where idPlayer = \'%d\';",
							stack.getFirst().getId());
				} else if (stack.getFirst().getActionName().equals(ActionEnum.INJURY)) {
					query = String.format("update theprojectdata.player set injured = '1' where idPlayer = \'%d\';",
							stack.getFirst().getId());
				} else if (stack.getFirst().getActionName().equals(ActionEnum.CATCH)) {
					query = String.format(
							"update theprojectdata.player set catches = catches + 1 where idPlayer = \'%d\';",
							stack.getFirst().getId());
				}
				statement.execute(query);
				stack.removeFirst();
			}
		}
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		GameHandler that = (GameHandler) o;

		if (playerList != null && !playerList.isEmpty())
			if (!Objects.equals(playerList, that.playerList))
				return false;

		if (stack != null && !stack.isEmpty())
			return Objects.equals(stack, that.stack);

		return true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(playerList, stack);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("Game Handler\nPlayer List:");

		if (this.playerList != null) {
			for (Player p : playerList.values()) {
				builder.append("\t").append(p.toString());
			}
			builder.append("\n");
		} else {
			builder.append("\tnull\n");
		}

		return builder.toString();
	}
}
