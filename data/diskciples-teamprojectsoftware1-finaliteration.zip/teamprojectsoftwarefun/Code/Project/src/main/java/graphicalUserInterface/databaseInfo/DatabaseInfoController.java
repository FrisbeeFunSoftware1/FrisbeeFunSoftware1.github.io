package graphicalUserInterface.databaseInfo;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

import database.DBConnection;
import graphicalUserInterface.Main;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class DatabaseInfoController {
	public static final Logger logger = Logger.getLogger(DatabaseInfoController.class.getName());
	@FXML
	private TextField usernameField;
	@FXML
	private PasswordField passwordField;
    @FXML
    private Text statusField;
    
	@FXML
	private void setCredentials() throws IOException {
		DBConnection.getInstance().setCredentials(usernameField.getText(), passwordField.getText());
		Connection temporary = null;
		try {
			temporary = DBConnection.getInstance().getConnection();
		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
		}
		if (temporary == null) {
			statusField.setFill(Color.rgb(255, 0, 0));
			statusField.setText("Incorrect credentials or database isn't set up correctly... try again.");
		} else {
			Main.showLoginPage();
		}
	}

	@FXML
	private void cancel() {
		throw new RuntimeException("Bad database");
	}
}
