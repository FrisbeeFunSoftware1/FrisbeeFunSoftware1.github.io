package graphicalUserInterface;

import database.GameHandler;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Logger;

public class Main extends Application {
	public static final Logger logger = Logger.getLogger(GameHandler.class.getName());
	private static Stage primaryStage = null;
	private static BorderPane mainLayout = null;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws IOException, SQLException {
		Main.setPrimary(primaryStage);
		Main.primaryStage.setTitle("Frisbee Fun Software I");
		Main.primaryStage.getIcons().add(new Image(this.getClass().getResourceAsStream("view/cerny.png")));
		showMainView();
		showDatabaseInfo();
	}

	private static void setPrimary(Stage primaryStage2) {
		Main.primaryStage = primaryStage2;
	}

	public static void showLoginPage() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("loginPage/LoginPage.fxml"));
		BorderPane mainItems = loader.load();
		mainLayout.setCenter(mainItems);
	}

	private void showMainView() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainView.fxml"));
		mainLayout = loader.load();
		Scene scene = new Scene(mainLayout, 800, 600);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void showMainItems() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainItems.fxml"));
		BorderPane mainItems = loader.load();
		mainLayout.setCenter(mainItems);
	}
	
	public static void showDatabaseInfo() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("databaseInfo/DatabaseInfo.fxml"));
		BorderPane mainItems = loader.load();
		mainLayout.setCenter(mainItems);
	}

	public static void showCreatePlayerScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("createNewPlayer/CreatePlayer.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);

		/*
		 * Stage addDialogStage = new Stage();
		 * addDialogStage.setTitle("Add new Player");
		 * addDialogStage.initModality(Modality.WINDOW_MODAL);
		 * addDialogStage.initOwner(primaryStage); Scene scene = new
		 * Scene(createPlayer); addDialogStage.setScene(scene);
		 * addDialogStage.showAndWait();
		 */
	}

	public static void showPreGameScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("preGame/PreGame.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}

	public static void showGameScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("game/Game.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}

	public static void showGameOverScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("gameOver/GameOver.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}

	public static void showTurnoverScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("turnover/Turnover.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}

	public static void showPlayerStatsScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("playerStats/PlayerStats.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}

	public static void showCreateNewPlayerVerificationScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("createNewPlayerVerification/CreateNewPlayerVerification.fxml"));
		BorderPane createPlayer = loader.load();
		mainLayout.setCenter(createPlayer);
	}
}
