package graphicalUserInterface.gameOver;

import graphicalUserInterface.Main;
import javafx.fxml.FXML;

import java.io.IOException;

public class GameOverController {

    @FXML
    private void goFinished() throws IOException {
        Main.showMainItems();
    }
}
