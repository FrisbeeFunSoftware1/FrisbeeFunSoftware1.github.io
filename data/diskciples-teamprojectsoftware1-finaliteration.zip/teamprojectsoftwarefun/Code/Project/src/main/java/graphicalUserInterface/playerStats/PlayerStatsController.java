package graphicalUserInterface.playerStats;

import database.DBConnection;
import graphicalUserInterface.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PlayerStatsController {
    public static final Logger logger = Logger.getLogger(PlayerStatsController.class.getName());
    @FXML
    private ChoiceBox<String> PlayerSelected;

    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField height;
    @FXML
    private TextField age;
    @FXML
    private TextField weight;
    @FXML
    private TextField dominantHand;
    @FXML
    private TextField passes;
    @FXML
    private TextField completions;
    @FXML
    private TextField catches;
    @FXML
    private TextField scores;
    @FXML
    private TextField injured;
    @FXML
    private TextField games;

    @FXML
    private void goHome() throws IOException {
        Main.showMainItems();
    }

    @FXML
    private void initialize() throws SQLException, NullPointerException {
        Connection dbConnection = DBConnection.getInstance().getConnection();
        if (dbConnection == null) {
            throw new SQLException("getDBConnection returned a null connection.");
        }

        try (Statement statement = dbConnection.createStatement()) {
            String query = "Select name from TheProjectData.Player";
            ArrayList<String> tempArray = new ArrayList<>();
            try (ResultSet rs = statement.executeQuery(query)) {

                if (rs.next()) {
                    do {
                        tempArray.add(rs.getString("name"));
                    } while (rs.next());
                }

                ObservableList<String> available = FXCollections.observableArrayList(tempArray);

                PlayerSelected.setItems(available);
                rs.close();
            }
            statement.close();
        }
    }

    @FXML
    private void getStats() throws SQLException {
        if (PlayerSelected != null) {
            String query = "Select * from TheProjectData.Player where name = \"" + PlayerSelected.getValue() + "\"";
            Connection dbConnection = DBConnection.getInstance().getConnection();
            if (dbConnection == null) {
                throw new SQLException("getDBConnection returned a null connection.");
            }

            try (Statement statement = dbConnection.createStatement()) {
                try (ResultSet rs = statement.executeQuery(query)) {
                    if (rs.next()) {
                        id.setText(rs.getString("idPlayer"));
                        height.setText(rs.getString("Height"));
                        weight.setText(rs.getString("Weight"));
                        age.setText(rs.getString("Age"));
                        name.setText(rs.getString("Name"));
                        dominantHand.setText(rs.getString("Hand"));
                        passes.setText(rs.getString("Passes"));
                        completions.setText(rs.getString("Completions"));
                        catches.setText(rs.getString("Catches"));
                        scores.setText(rs.getString("Scores"));
                        String tempInjuredString = rs.getString("Injured");
                        if ("0".equals(tempInjuredString)) {
                            injured.setText("no");
                        } else {
                            injured.setText("yes");
                        }
                        games.setText(rs.getString("GamesPlayed"));
                    }
                    rs.close();
                }
                statement.close();
            }
        }
    }

    @FXML
    private void deletePlayer() throws SQLException {
        if (PlayerSelected != null) {
            String query = "Delete from theprojectdata.player where name = \"" + PlayerSelected.getValue() + "\"";
            Connection dbConnection = DBConnection.getInstance().getConnection();
            if (dbConnection != null) {
                try (Statement statement = dbConnection.createStatement()) {
                    statement.execute(query);
                    statement.close();
                }
            }
            initialize();
        }
    }

    @FXML
    private void updateStats() throws SQLException {
        if (PlayerSelected != null) {
            String tempInjuredString;

            if ("no".equals(injured.getText().toLowerCase()) || "0".equals(injured.getText())) {
                tempInjuredString = "0";
            } else {
                tempInjuredString = "1";
            }
            PreparedStatement stmt = null;
            Connection dbConnection = null;
            try {
                dbConnection = DBConnection.getInstance().getConnection();
                stmt = dbConnection.prepareStatement("Update TheProjectData.Player SET Name = ?, Height = ?, Weight = ?, Age = ?, Hand = ?, Passes = ?, Completions = ?, Catches = ?, Scores = ?, Injured = ?, GamesPlayed = ? WHERE idPlayer = ?;");

                stmt.setString(1, name.getText());
                stmt.setString(2, height.getText());
                stmt.setString(3, weight.getText());
                stmt.setInt(4, Integer.parseInt(age.getText()));
                stmt.setString(5, dominantHand.getText());
                stmt.setInt(6, Integer.parseInt(passes.getText()));
                stmt.setInt(7, Integer.parseInt(completions.getText()));
                stmt.setInt(8, Integer.parseInt(catches.getText()));
                stmt.setInt(9, Integer.parseInt(scores.getText()));
                stmt.setInt(10, Integer.parseInt(tempInjuredString));
                stmt.setInt(11, Integer.parseInt(games.getText()));
                stmt.setInt(12, Integer.parseInt(id.getText()));

                try (Statement statement = dbConnection.createStatement()) {
                    stmt.executeUpdate();
                    statement.close();
                }
            } finally {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (Exception e) {
                    logger.log(Level.SEVERE, e.getMessage());
                }

                try {
                    if (dbConnection != null) {
                        dbConnection.close();
                    }
                } catch (Exception e) {
                    logger.log(Level.SEVERE, e.getMessage());
                }
            }
        }
    }
}
