package graphicalUserInterface.createNewPlayerVerification;

import graphicalUserInterface.Main;
import javafx.fxml.FXML;

import java.io.IOException;

public class CreateNewPlayerVerificationController {

    @FXML
    private void goHome() throws IOException {
        Main.showMainItems();
    }
}
