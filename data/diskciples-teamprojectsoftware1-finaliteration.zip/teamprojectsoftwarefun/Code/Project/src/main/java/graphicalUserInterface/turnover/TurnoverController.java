package graphicalUserInterface.turnover;

import java.io.IOException;

import graphicalUserInterface.Main;
import javafx.fxml.FXML;

public class TurnoverController {

	@FXML
	private void goCancel() throws IOException {
		Main.showMainItems();
	}

	@FXML
	private void goGameOver() throws IOException {
		Main.showGameOverScene();
	}

	@FXML
	private void goGame() throws IOException {
		Main.showGameScene();
	}

	@FXML
	private void goTurnover() throws IOException {
		Main.showTurnoverScene();
	}
}
